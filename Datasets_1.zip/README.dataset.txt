# bone fracture detection > v4
https://universe.roboflow.com/veda/bone-fracture-detection-daoon

Provided by a Roboflow user
License: CC BY 4.0

